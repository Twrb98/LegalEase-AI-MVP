# LegalEase AI
This is the LegalEase AI MVP project.